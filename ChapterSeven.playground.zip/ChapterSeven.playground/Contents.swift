import UIKit

class Shape {
    var numberOfSides = 0
    // Experimemnt 1
    let isConnex: Bool = true
    func simpleDescription() -> String {
        return "A shape with \(numberOfSides) sides."
    }
    // Experimemnt 1
    func incrementSides(by incr: Int) {
        numberOfSides += incr
    }
}

class NamedShape {
    var numberOfSides: Int = 0
    var name: String
    
    init(name: String) {
        self.name = name
    }
    
    func simpleDescription() -> String {
        return "A shape with \(numberOfSides) sides."
    }
}


class Circle: NamedShape{
    var radius: Double
    
    init(name: String, radius: Double) {
        self.radius = radius
        super.init(name: name)
    }
    override func simpleDescription() -> String {
        return "A circle with radius \(radius)."
    }
    func area() -> Double {
        return radius * radius * Double.pi
    }
}
