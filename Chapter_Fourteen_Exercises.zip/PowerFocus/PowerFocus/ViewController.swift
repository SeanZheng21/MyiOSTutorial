//
//  ViewController.swift
//  PowerFocus
//
//  Created by Carlistle ZHENG on 9/22/19.
//  Copyright © 2019 Carlistle ZHENG. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var timer: Timer?
    var timerStatus: TimerStatus = .stopped
    
    
    // The timer model that keeps track of work/break cycles
    private var focusTimer: FocusTimer!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        focusTimer = FocusTimer(3, 1, 2, 3, true)
        
        timeLabel.text = "\(focusTimer.workLength):00"
        timer = Timer.scheduledTimer(timeInterval: 0.05,
                                    target: self,
                                    selector: #selector(ViewController.decSec),
                                    userInfo: nil,
                                    repeats: true)
        stopButton.isHidden = true
        timerStatus = .stopped
    }

    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var statusLabel: UILabel!
    @IBOutlet weak var startButton: UIButton!
    @IBOutlet weak var stopButton: UIButton!
    @IBOutlet weak var optionsButton: UIButton!
    @IBOutlet weak var backgroundImageView: UIImageView!
    
    @IBAction func startButtonTouched(_ sender: UIButton) {
        switch timerStatus {
        case .enabled:
            // pause the timer from enabled
            startButton.setTitle("Resume", for: .normal)
            statusLabel.text = "\(focusTimer.isWork() ? "Work" : "Break") paused"
            timerStatus = .paused
        case .stopped:
            // start the timer from stopped
            startButton.setTitle("Pause", for: .normal)
            timerStatus = .enabled
            focusTimer.setSecondLeft(to: focusTimer.workLength * 60)
            statusLabel.text = "Work"
            stopButton.isHidden = false
            setTheme(to: .work)
        case .paused:
            // resume the timer from paused
            startButton.setTitle("Pause", for: .normal)
            statusLabel.text = focusTimer.isWork() ? "Work" : "Break"
            timerStatus = .enabled
        }

    }
    
    @IBAction func stopButtonTouched(_ sender: UIButton) {
        timeLabel.text = "\(focusTimer.workLength):00"
        timerStatus = .stopped
        startButton.setTitle("Start", for: .normal)
        statusLabel.text = "Work"
        focusTimer.setSecondLeft(to: focusTimer.workLength * 60)
        focusTimer.initCycles()
        setTheme(to: .work)
        stopButton.isHidden = true
    }
    
    @IBAction func optionsButtonTouched(_ sender: UIButton) {
        print("Option button touched")
    }
    
    @objc func decSec() -> Void {
        guard timerStatus == .enabled else {
            return
        }
        if focusTimer.decrementSecond() {
            switch focusTimer.getActivity() {
            case .longBreak:
                _ = focusTimer.incrementCompletedCycles()
                focusTimer.setActivity(to: .work)
                focusTimer.setSecondLeft(to: focusTimer.workLength * 60)
                statusLabel.text = "Work"
                setTheme(to: .work)
                print("Start of: work")
            case .shortBreak:
                _ = focusTimer.incrementCompletedCycles()
                focusTimer.setActivity(to: .work)
                focusTimer.setSecondLeft(to: focusTimer.workLength * 60)
                statusLabel.text = "Work"
                setTheme(to: .work)
                print("Start of: work")
            case .work:
                if focusTimer.nextBreakIsLongBreak() {
                    focusTimer.setActivity(to: .longBreak)
                    focusTimer.setSecondLeft(to: focusTimer.longBreakLength * 60)
                    setTheme(to: .longBreak)
                    print("Start of: long break")
                } else {
                    focusTimer.setActivity(to: .shortBreak)
                    focusTimer.setSecondLeft(to: focusTimer.breakLength * 60)
                    setTheme(to: .shortBreak)
                    print("Start of: short break")
                }
                statusLabel.text = "Break"
            }
            let sec = focusTimer.getSecondLeft()
            timeLabel.text = sec.timeFormat()
        } else {
            let sec = focusTimer.getSecondLeft()
            timeLabel.text = sec.timeFormat()
        }
    }
    
    func setTheme(to activityType: ActivityType) -> Void {
        let greenColor = #colorLiteral(red: 0.3215686275, green: 0.6470588235, blue: 0.4823529412, alpha: 1)
        let redColor = #colorLiteral(red: 0.8941176471, green: 0.3098039216, blue: 0.4470588235, alpha: 1)
        switch activityType {
        case .work:
            backgroundImageView.image = UIImage(named: "work_background")
            stopButton.titleLabel?.textColor = redColor
            optionsButton.titleLabel?.textColor = redColor
        case .longBreak:
            backgroundImageView.image = UIImage(named: "break_background")
            stopButton.titleLabel?.textColor = greenColor
            optionsButton.titleLabel?.textColor = greenColor
        case .shortBreak:
            backgroundImageView.image = UIImage(named: "break_background")
            stopButton.titleLabel?.textColor = greenColor
            optionsButton.titleLabel?.textColor = greenColor
        }
    }
    
    
    enum TimerStatus {
        case stopped
        case paused
        case enabled
    }
    
}

extension Int {
    func timeFormat() -> String {
        if self % 60 >= 10 {
            return "\(self / 60):\( self % 60)"
        } else {
            return "\(self / 60):0\( self % 60)"
        }
    }
}
