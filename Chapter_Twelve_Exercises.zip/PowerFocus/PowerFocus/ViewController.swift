//
//  ViewController.swift
//  PowerFocus
//
//  Created by Carlistle ZHENG on 9/22/19.
//  Copyright © 2019 Carlistle ZHENG. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        timeLabel.text = "01:59"
        
        // Disable the stop button
//        stopButton.setTitle(" ", for: .normal)
//        stopButton.isEnabled = false
        
        // Hide the start button
//        startButton.isHidden = true
    }

    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var workLabel: UILabel!
    @IBOutlet weak var startButton: UIButton!
    @IBOutlet weak var stopButton: UIButton!
    @IBOutlet weak var optionsButton: UIButton!
    
    @IBAction func startButtonTouched(_ sender: UIButton) {
        print("\(sender.titleLabel?.text ?? "") button touched")
    }
    
    @IBAction func stopButtonTouched(_ sender: UIButton) {
        print("\(sender.titleLabel?.text ?? "") button touched")
    }
    
    @IBAction func optionsButtonTouched(_ sender: UIButton) {
        print("\(sender.titleLabel?.text ?? "") button touched")
    }
}

