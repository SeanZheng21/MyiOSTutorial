//
//  ActivityType.swift
//  PowerFocus
//
//  Created by Carlistle ZHENG on 10/11/19.
//  Copyright © 2019 Carlistle ZHENG. All rights reserved.
//

import Foundation

enum ActivityType: String {
    case work = "work"
    case shortBreak = "shortBreak"
    case longBreak = "longBreak"
}
