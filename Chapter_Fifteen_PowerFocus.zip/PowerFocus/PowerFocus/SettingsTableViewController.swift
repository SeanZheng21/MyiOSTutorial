//
//  SettingsTableViewController.swift
//  PowerFocus
//
//  Created by Carlistle ZHENG on 2/21/20.
//  Copyright © 2020 Carlistle ZHENG. All rights reserved.
//

import UIKit

class SettingsTableViewController: UITableViewController {
    
    private var headers = ["    TIMER LENGTH", "    LONG BREAK", "    ALARM", "    STATS", "    SCREEN LOCK"]

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.backgroundColor = UIColor(red: 241.0/255.0, green: 241.0/255.0, blue: 246.0/255.0, alpha: 1.0)
        tableView.sectionFooterHeight = 80
        tableView.sectionHeaderHeight = 35
        tableView.isScrollEnabled = false
        tableView.tableFooterView = UIView(frame: CGRect.zero)
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return headers[section]
    }
    
    override func tableView(_ tableView: UITableView, titleForFooterInSection section: Int) -> String? {
        if section == 2 {
            return "Your device Settings or Mute switch will override the above alarm options"
        } else {
            return nil
        }
    }

    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView(frame: CGRect(x: 0, y: 0, width: tableView.bounds.size.width, height: 50))
        headerView.backgroundColor = .clear
        let label = UILabel(frame: CGRect(x: 0, y: 0, width: 200, height: 40))
        label.text = headers[section]
        label.textAlignment = .left
        label.textColor = .darkGray
        label.font = label.font.withSize(15.0)
        headerView.addSubview(label)
        return headerView
    }

    override func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        print(section)
        let footerView = UIView(frame: CGRect(x: 0, y: 0, width: tableView.bounds.size.width, height: 80))
        footerView.backgroundColor = .clear
        let label = UILabel(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 80))
        label.text = "    Your device Settings or Mute switch will override \n    the above alarm options"
        label.numberOfLines = 2
        label.font = label.font.withSize(15.0)
        label.textAlignment = .left
        label.textColor = .darkGray
        footerView.addSubview(label)
        return footerView
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
