import UIKit

var str = "Hello, world!"
print(str)
// Prints "Hello, world!"
