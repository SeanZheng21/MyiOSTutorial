//
//  FocusTimer.swift
//  PowerFocus
//
//  Created by Carlistle ZHENG on 10/11/19.
//  Copyright © 2019 Carlistle ZHENG. All rights reserved.
//

import Foundation

class FocusTimer {
    
    // Static constants for constructor
    private static let defaultLongBreakFreq = 3
    private static let defaultEnableLongBreak = true
    private static let defaultActivity = ActivityType.work
    
    // Length of  activities
    private(set) var workLength: Int
    private(set) var breakLength: Int
    private(set) var longBreakLength: Int
    
    // number of completed work-(long)break cycles
    private var completedCircles = 0
    
    // number of cycles between each long break
    private(set) var longBreakFreq: Int
    
    // If the timer enables long break cycles
    private(set) var hasLongBreak: Bool
    
    // The current activity type
    private var activity: ActivityType
    // current activity's time left
    private var secondLeft = 0
    
    init(_ workLg: Int, _ breakLg: Int, _ longBreakLg: Int, _ longBreakFreq: Int = FocusTimer.defaultLongBreakFreq,
         _ hasLongBreak: Bool = FocusTimer.defaultEnableLongBreak) {
        self.workLength = workLg
        self.breakLength = breakLg
        self.longBreakLength = longBreakLg
        self.longBreakFreq = longBreakFreq
        self.hasLongBreak = hasLongBreak
        self.completedCircles = 0
        activity = FocusTimer.defaultActivity
    }
}
