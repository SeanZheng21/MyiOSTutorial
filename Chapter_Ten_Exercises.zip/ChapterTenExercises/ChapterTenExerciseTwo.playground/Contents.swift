import UIKit

class Glyph {
    private var charVal: Character
    
    public func display() -> Void {
        print("Glyph with character: \(charVal)\n")
    }
    
    init(_ char: Character) {
        self.charVal = char
    }
}


class GlyphFactory {
    public static let INSTANCE: GlyphFactory = GlyphFactory()
    
    private var glyphCache: [Character: Glyph] = [:]
    
    private init() {
        glyphCache = [:]
    }
    
    public func getGlyph(from char: Character) -> Glyph {
        if glyphCache.keys.contains(char) {
            print("returning an existing glyph of \(char)")
            return glyphCache[char]!
        } else {
            print("returning a new glyph of \(char)")
            let tmp_glyph = Glyph(char)
            glyphCache[char] = tmp_glyph
            return tmp_glyph
        }
    }
}

GlyphFactory.INSTANCE.getGlyph(from: "a").display() // returning a new glyph of a
                                                    // Glyph with character: a
GlyphFactory.INSTANCE.getGlyph(from: "b").display() // returning a new glyph of b
                                                    // Glyph with character: b
GlyphFactory.INSTANCE.getGlyph(from: "a").display() // returning an existing glyph of a
                                                    // Glyph with character: a
GlyphFactory.INSTANCE.getGlyph(from: "c").display() // returning a new glyph of c
                                                    // Glyph with character: c
GlyphFactory.INSTANCE.getGlyph(from: "c").display() // returning an existing glyph of c
                                                    // Glyph with character: c
