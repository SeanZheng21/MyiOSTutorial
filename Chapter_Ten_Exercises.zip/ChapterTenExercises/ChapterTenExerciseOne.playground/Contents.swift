import UIKit

class Foo {
    // a private bar, can't be accessed directly from outside
    private var bar: Int = 5
    
    // a public getter, but no public setter
    public func getBar() -> Int {
        return bar
    }
}

let foo = Foo()
print(foo.getBar())
// foo.bar = 10         error: 'bar' is inaccessible due to 'private' protection level




class FooTwo {
    var bar: Int {
        get {
            return realBar
        }
    }
    private var realBar: Int = 5
}

let fooTwo = FooTwo()
print(fooTwo.bar)
// fooTwo.bar = 10     Cannot assign to property: 'bar' is a get-only property


