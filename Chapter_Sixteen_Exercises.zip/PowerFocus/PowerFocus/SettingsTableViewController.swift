//
//  SettingsTableViewController.swift
//  PowerFocus
//
//  Created by Carlistle ZHENG on 2/21/20.
//  Copyright © 2020 Carlistle ZHENG. All rights reserved.
//

import UIKit

class SettingsTableViewController: UITableViewController {
    
    private var headers = ["    TIMER LENGTH", "    LONG BREAK", "    ALARM", "    STATS", "    SCREEN LOCK"]
    private var userDefaults: UserDefaults = .standard
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.setNavigationBarHidden(false, animated: true)
        tableView.backgroundColor = UIColor(red: 241.0/255.0, green: 241.0/255.0, blue: 246.0/255.0, alpha: 1.0)
        tableView.sectionFooterHeight = 80
        tableView.sectionHeaderHeight = 35
        tableView.isScrollEnabled = false
        tableView.tableFooterView = UIView(frame: CGRect.zero)
        updateOutlets()

    }
    
    override func viewWillAppear(_ animated: Bool) {
        updateOutlets()
    }
    
    private func updateOutlets() -> Void {
        workLengthLabel.text = "\(userDefaults.integer(forKey: "workLength")) minutes"
        breakLengthLabel.text = "\(userDefaults.integer(forKey: "breakLength")) minutes"
        longBreakLengthLabel.text = "\(userDefaults.integer(forKey: "longBreakLength")) minutes"
        frequencyLabel.text = "Every \(userDefaults.integer(forKey: "longBreakFrequency"))"
        enableLongBreakSwich.isOn = userDefaults.bool(forKey: "enableLongBreak")
        enableVibrationSwitch.isOn = userDefaults.bool(forKey: "enableVibration")
        enableSoundSwitch.isOn = userDefaults.bool(forKey: "enableSound")
        lockSwitch.isOn = userDefaults.bool(forKey: "enablePreventLock")
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return headers[section]
    }
    
    override func tableView(_ tableView: UITableView, titleForFooterInSection section: Int) -> String? {
        if section == 2 {
            return "Your device Settings or Mute switch will override the above alarm options"
        } else {
            return nil
        }
    }

    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView(frame: CGRect(x: 0, y: 0, width: tableView.bounds.size.width, height: 50))
        headerView.backgroundColor = .clear
        let label = UILabel(frame: CGRect(x: 0, y: 0, width: 200, height: 40))
        label.text = headers[section]
        label.textAlignment = .left
        label.textColor = .darkGray
        label.font = label.font.withSize(15.0)
        headerView.addSubview(label)
        return headerView
    }

    override func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let footerView = UIView(frame: CGRect(x: 0, y: 0, width: tableView.bounds.size.width, height: 80))
        footerView.backgroundColor = .clear
        let label = UILabel(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 80))
        label.text = "    Your device Settings or Mute switch will override \n    the above alarm options"
        label.numberOfLines = 2
        label.font = label.font.withSize(15.0)
        label.textAlignment = .left
        label.textColor = .darkGray
        footerView.addSubview(label)
        return footerView
    }
    
    // MARK:- Adjust work length
    @IBOutlet weak var workLengthLabel: UILabel!
    @IBAction func workPlusTouched(_ sender: UIButton) {
        let currentWorkLength = userDefaults.integer(forKey: "workLength")
        if currentWorkLength < 59 {
            userDefaults.set(currentWorkLength + 1, forKey: "workLength")
            updateOutlets()
        }
    }
    
    @IBAction func workMinusTouched(_ sender: UIButton) {
        let currentWorkLength = userDefaults.integer(forKey: "workLength")
        if currentWorkLength > 5 {
            userDefaults.set(currentWorkLength - 1, forKey: "workLength")
            updateOutlets()
        }
    }
    
    // MARK:- Adjust break length
    @IBOutlet weak var breakLengthLabel: UILabel!
    @IBAction func breakPlusTouched(_ sender: UIButton) {
        let currentBreakLength = userDefaults.integer(forKey: "breakLength")
        if currentBreakLength < 15 {
            userDefaults.set(currentBreakLength + 1, forKey: "breakLength")
            updateOutlets()
        }
    }
    
    @IBAction func breakMinusTouched(_ sender: UIButton) {
        let currentBreakLength = userDefaults.integer(forKey: "breakLength")
        if currentBreakLength > 2 {
            userDefaults.set(currentBreakLength - 1, forKey: "breakLength")
            updateOutlets()
        }
    }
    
    // MARK:- Adjust long break length
    @IBOutlet weak var longBreakLengthLabel: UILabel!
    @IBAction func longBreakPlusTouched(_ sender: UIButton) {
        let currentLongBreakLength = userDefaults.integer(forKey: "longBreakLength")
        if currentLongBreakLength < 59 {
            userDefaults.set(currentLongBreakLength + 1, forKey: "longBreakLength")
            updateOutlets()
        }
    }
    
    @IBAction func longBreakMinusTouched(_ sender: UIButton) {
        let currentLongBreakLength = userDefaults.integer(forKey: "longBreakLength")
        if currentLongBreakLength > 5 {
            userDefaults.set(currentLongBreakLength - 1, forKey: "longBreakLength")
            updateOutlets()
        }
    }
    
    // MARK:- Adjust long break frequency
    @IBOutlet weak var frequencyLabel: UILabel!
    @IBAction func freqPlusTouched(_ sender: UIButton) {
        let currentLongBreakFreq = userDefaults.integer(forKey: "longBreakFrequency")
        if currentLongBreakFreq < 10 {
            userDefaults.set(currentLongBreakFreq + 1, forKey: "longBreakFrequency")
            updateOutlets()
        }
    }
    @IBAction func freqMinusTouched(_ sender: UIButton) {
        let currentLongBreakFreq = userDefaults.integer(forKey: "longBreakFrequency")
        if currentLongBreakFreq > 1 {
            userDefaults.set(currentLongBreakFreq - 1, forKey: "longBreakFrequency")
            updateOutlets()
        }
    }
    
    // MARK: - Enable long break
    @IBOutlet weak var enableLongBreakSwich: UISwitch!
    @IBAction func enableLongBreakChanged(_ sender: UISwitch) {
        userDefaults.set(sender.isOn, forKey: "enableLongBreak")
        updateOutlets()
    }
    
    // MARK: - Enable vibration
    @IBOutlet weak var enableVibrationSwitch: UISwitch!
    @IBAction func enableVibrationChanged(_ sender: UISwitch) {
        userDefaults.set(sender.isOn, forKey: "enableVibration")
        updateOutlets()
    }
    
    // MARK: - Enable sound
    @IBOutlet weak var enableSoundSwitch: UISwitch!
    @IBAction func enableSoundChanged(_ sender: UISwitch) {
        userDefaults.set(sender.isOn, forKey: "enableSound")
        updateOutlets()
    }
    
    // MARK: - Enable auto lock
    @IBOutlet weak var lockSwitch: UISwitch!
    @IBAction func lockChanged(_ sender: UISwitch) {
        userDefaults.set(sender.isOn, forKey: "enablePreventLock")
        updateOutlets()
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
