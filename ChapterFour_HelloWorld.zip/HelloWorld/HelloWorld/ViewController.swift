//
//  ViewController.swift
//  HelloWorld
//
//  Created by Carlistle ZHENG on 2/27/19.
//  Copyright © 2019 Carlistle ZHENG. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func showMessage(_ sender: UIButton) {
        // Create an alert controller object to display an alert
        let alertController = UIAlertController(title: "Welcome to my hello world app", message: "Hello World!", preferredStyle: .alert)
        // Add an action OK to the alert controller
        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        // Present the alert controller with animation
        present(alertController, animated: true, completion: nil)
    }
    
}

