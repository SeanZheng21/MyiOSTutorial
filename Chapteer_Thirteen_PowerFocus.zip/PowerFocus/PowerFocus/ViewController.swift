//
//  ViewController.swift
//  PowerFocus
//
//  Created by Carlistle ZHENG on 9/22/19.
//  Copyright © 2019 Carlistle ZHENG. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var timer: Timer?
    
    // The timer model that keeps track of work/break cycles
    private var focusTimer: FocusTimer!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        timeLabel.text = "00:00"
        
        timer = Timer.scheduledTimer(timeInterval: 1,
                                     target: self,
                                     selector: #selector(ViewController.decSec),
                                     userInfo: nil,
                                     repeats: true)
        timer?.invalidate()
        
        focusTimer = FocusTimer(25, 5, 15, 3, true)
    }

    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var workLabel: UILabel!
    @IBOutlet weak var startButton: UIButton!
    @IBOutlet weak var stopButton: UIButton!
    @IBOutlet weak var optionsButton: UIButton!
    
    @IBAction func startButtonTouched(_ sender: UIButton) {
        print("\(sender.titleLabel?.text ?? "") button touched")
        startButton.isHidden = true
        focusTimer.setActivity(to: .work)
        focusTimer.setSecondLeft(to: focusTimer.workLength * 60)
        
        timer = Timer.scheduledTimer(timeInterval: 1,
                                    target: self,
                                    selector: #selector(ViewController.decSec),
                                    userInfo: nil,
                                    repeats: true)
    }
    
    @IBAction func stopButtonTouched(_ sender: UIButton) {
        print("\(sender.titleLabel?.text ?? "") button touched")
        if timer?.isValid ?? false {
            timer?.invalidate()
        }
    }
    
    @IBAction func optionsButtonTouched(_ sender: UIButton) {
        print("\(sender.titleLabel?.text ?? "") button touched")
    }
    
    @objc func decSec() -> Void {
        if focusTimer.decrementSecond() {
            // TODO update the view when the activity has finished
            print("Time is up")
        } else {
            let sec = focusTimer.getSecondLeft()
            timeLabel.text = "\(sec / 60):\( sec % 60)"
        }
    }
}

