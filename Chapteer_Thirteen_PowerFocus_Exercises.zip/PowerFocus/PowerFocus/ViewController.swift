//
//  ViewController.swift
//  PowerFocus
//
//  Created by Carlistle ZHENG on 9/22/19.
//  Copyright © 2019 Carlistle ZHENG. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var timer: Timer?
    var timerStatus: TimerStatus = .stoped
    
    
    // The timer model that keeps track of work/break cycles
    private var focusTimer: FocusTimer!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        focusTimer = FocusTimer(25, 5, 15, 3, true)
        
        timeLabel.text = "\(focusTimer.workLength):00"
        timer = Timer.scheduledTimer(timeInterval: 1,
                                    target: self,
                                    selector: #selector(ViewController.decSec),
                                    userInfo: nil,
                                    repeats: true)
        stopButton.isHidden = true
        timerStatus = .stoped
    }

    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var workLabel: UILabel!
    @IBOutlet weak var startButton: UIButton!
    @IBOutlet weak var stopButton: UIButton!
    @IBOutlet weak var optionsButton: UIButton!
    
    @IBAction func startButtonTouched(_ sender: UIButton) {
        switch timerStatus {
        case .enabled:
            // pause the timer from enabled
            startButton.setTitle("Resume", for: .normal)
            timerStatus = .paused
        case .stoped:
            // start the timer from stoped
            startButton.setTitle("Pause", for: .normal)
            timerStatus = .enabled
            focusTimer.setSecondLeft(to: focusTimer.workLength * 60)
            stopButton.isHidden = false
        case .paused:
            // resume the timer from paused
            startButton.setTitle("Pause", for: .normal)
            timerStatus = .enabled
        }

    }
    
    @IBAction func stopButtonTouched(_ sender: UIButton) {
        print("\(sender.titleLabel?.text ?? "") button touched")
        timeLabel.text = "\(focusTimer.workLength):00"
        timerStatus = .stoped
        startButton.setTitle("Start", for: .normal)
        focusTimer.setSecondLeft(to: focusTimer.workLength * 60)
        stopButton.isHidden = true
    }
    
    @IBAction func optionsButtonTouched(_ sender: UIButton) {
        print("\(sender.titleLabel?.text ?? "") button touched")
    }
    
    @objc func decSec() -> Void {
        guard timerStatus == .enabled else {
            return
        }
        if focusTimer.decrementSecond() {
            // TODO update the view when the activity has finished
            print("Time is up")
        } else {
            let sec = focusTimer.getSecondLeft()
            timeLabel.text = "\(sec / 60):\( sec % 60)"
        }
    }
    
    
    
    enum TimerStatus {
        case stoped
        case paused
        case enabled
    }
}

