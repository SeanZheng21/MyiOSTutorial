//
//  DefaultKeys.swift
//  PowerFocus
//
//  Created by Carlistle ZHENG on 3/6/20.
//  Copyright © 2020 Carlistle ZHENG. All rights reserved.
//

import Foundation

// Enum for user defaults key access
enum DefaultKeys: String {
    case workLength = "workLength"
    case breakLength = "breakLength"
    case longBreakLength = "longBreakLength"
    case longBreakFrequency = "longBreakFrequency"
    case enableLongBreak = "enableLongBreak"
    case enableVibration = "enableVibration"
    case enableSound = "enableSound"
    case enablePreventLock = "enablePreventLock"
}
