import UIKit

let years = [1900, 2000, 2008, 2018, 2019]

func isLeapYear(for year: Int) -> Bool {
    var res = false
    if(year % 4 == 0){
        if(year % 100 != 0){
            res = true
        } else if( year % 400 == 0) {
            res = true
        }
    }
    return res
}

for year in years{
    print("Year \(year) is a leap year? \(isLeapYear(for: year))")
}
